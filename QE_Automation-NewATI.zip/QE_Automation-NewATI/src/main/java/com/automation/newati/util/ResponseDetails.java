package com.automation.newati.util;

public class ResponseDetails {
	private String Username;
	private String Password;
	private int InstitutionID;
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public int getInstitutionID() {
		return InstitutionID;
	}
	public void setInstitutionID(int institutionID) {
		InstitutionID = institutionID;
	}
	
}
